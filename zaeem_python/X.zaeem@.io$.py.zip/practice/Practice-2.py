# Program to print area and perimeter of square and rectangle

print("This program is to find the area and the  perimeter of a square and rectangle\n")

print("Choose the shape you want to find area and perimeter\n")
print(" 1. Rectangle \n 2. Square\n")
shape = input()

if(shape == str('1') or shape == "Rectangle" or shape == "rectangle"):
 length = int(input("Enter the length of a rectangle :  "))
 width = int(input("Enter the width of a rectangle :  "))
 area = length * width
 perimeter = 2 * (length + width)
 print("The area of the rectangle is: " + str(area))  
 print("The perimeter of the rectangle is: " + str(perimeter))

elif(shape == str('2') or shape == "Square" or shape == "square"):
 side = int(input("Enter the side of the square : "))
 area = side * side
 perimeter = 4 * side

 print("The area of the square is: " + str(area))  
 print("The perimeter of the square is: " + str(perimeter))

else:
 print("Entered invalid number or shape")

    
