# Adding two numbers, greater and lesser of two numbers, factorial of number

print("This is a basic calculator")

number1 = input("Enter your first number : ")

number2 = input("\nEnter your second number : ")

sum = int(number1) + int(number2)

print("\nThe sum of two numbers is: " + str(sum)) 

print("\nFinding lesser than or greater than numbers\n")

number1 = int(input("Enter your first number : "))

number2 = int(input("\nEnter your second number : "))

if number1 == number2:
    print("Both numbers are equal")    
elif number1 >= number2:
    print(str(number1) + " is greater than " + str(number2))
    print(str(number2) + " is lesser than " + str(number1))
else: 
    print(str(number1) + " is lesser than " + str(number2))
    print(str(number2) + " is greater than " + str(number1))



number = input()
fact = 1
while(number > 1):
 fact = fact*number
 number=number-1
 print(fact) 





