# Python file to do unit convertions

print("Choose an option from below:\none = Converting km to miles" + "\ntwo = Converting celsius to fahrenhiet" + "\nthree = Converting cm to meter" +  "\nfour = Converting ML to L" )
 #one = "Converting km to miles"
 #two =  "Converting celsius to fahrenhiet"
 #three = "Converting cm to meter"
 #four = "Converting ML to L"
choose = input("What do you choose? :  ")
if choose == "one":
  print("Converting km to miles")
  km = float(input("Enter the kilometers :  "))
  miles = 0.621371 * km
  print("%0.2f km is equal to %0.2f miles"%(km,miles))

elif choose == "two":
  print("\n\nConverting celsius to fahrenhiet")
  celsius = float(input("Enter the Celsius :  "))
  fahrenhiet = 1.8 * celsius + 32
  print("%0.2f celsius is equal to %0.2f fahrenhiet"%(celsius,fahrenhiet))

elif choose == "three":
  print("\n\nConverting cm to meter")
  centimeter = float(input("Enter the Centimeters = "))
  meter = centimeter/1000
  print("%0.2f Centimeters = %0.2f Meters" %(centimeter, meter))  

elif choose == "four":
  print("\n\nConverting ML to L")
  ml = float(input("Enter the Milileters = "))
  l = ml/1000
  print("%0.3f milliLitre = %0.3f Litre" %(ml,l))

else:
  print("Invalid entry...")

print("Thanks for your time")  
