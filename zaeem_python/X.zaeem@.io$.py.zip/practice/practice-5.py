# Python program to check if the input number is odd or even.

number = int(input("Enter a number: "))
if (number % 2) == 0:
   print("Number {0} is an even number".format(number))
else:
   print("Number {0} is an odd number".format(number))

#print("%i even or odd"%number)
