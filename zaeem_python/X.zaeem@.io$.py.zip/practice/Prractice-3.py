# Python program to swap two variables
print("Python program to swap two variables")
# To take inputs from the user
a = input("Enter the value of a :  ")
b = input("Enter the value of b :  ")

# create a temporary variable and swap the values
temporary = a
a = b
b = temporary
print("\n")
print("The swaped value of a is {}".format(a))
print("\n")
print("The swaped value of b is {}".format(b))
